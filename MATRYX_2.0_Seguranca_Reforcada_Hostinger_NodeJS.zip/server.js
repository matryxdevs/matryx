'use strict';
/**
 * MATRYX — servidor de superfície mínima (Node.js 22+).
 * Sem dependências de terceiros ou endpoints de administração públicos.
 * Em produção: requer SITE_URL HTTPS, chave AES-GCM e Turnstile configurados.
 */
const http = require('node:http');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { URL } = require('node:url');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const STORAGE_DIR = process.env.STORAGE_DIR ? path.resolve(process.env.STORAGE_DIR) : path.join(ROOT, 'storage');
const LEADS_FILE = path.join(STORAGE_DIR, 'leads.enc.jsonl');
const PRODUCTION = process.env.NODE_ENV === 'production';
const SITE_URL = (process.env.SITE_URL || '').trim();
const TURNSTILE_SITE_KEY = (process.env.TURNSTILE_SITE_KEY || '').trim();
const TURNSTILE_SECRET_KEY = (process.env.TURNSTILE_SECRET_KEY || '').trim();
const EXPECTED_HOSTNAME = SITE_URL ? new URL(SITE_URL).hostname : '';
const MAX_BODY_BYTES = 8 * 1024;

const files = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ['/style.css', ['style.css', 'text/css; charset=utf-8']],
  ['/script.js', ['script.js', 'text/javascript; charset=utf-8']],
  ['/config.js', ['config.js', 'text/javascript; charset=utf-8']],
  ['/assets/favicon.svg', ['assets/favicon.svg', 'image/svg+xml']],
  ['/assets/fundador.webp', ['assets/fundador.webp', 'image/webp']],
  ['/assets/fundador.jpg', ['assets/fundador.jpg', 'image/jpeg']]
]);

function setupKey() {
  if (STORAGE_DIR === PUBLIC_DIR || STORAGE_DIR.startsWith(PUBLIC_DIR + path.sep)) {
    throw new Error('STORAGE_DIR não pode estar dentro de public/.');
  }
  const raw = (process.env.LEADS_ENCRYPTION_KEY || '').trim();
  if (raw) {
    if (!/^[a-fA-F0-9]{64}$/.test(raw)) throw new Error('LEADS_ENCRYPTION_KEY deve conter 64 caracteres hexadecimais.');
    return Buffer.from(raw, 'hex');
  }
  if (PRODUCTION) throw new Error('Produção bloqueada: configure LEADS_ENCRYPTION_KEY.');
  fs.mkdirSync(STORAGE_DIR, { recursive: true, mode: 0o700 });
  const devKeyFile = path.join(STORAGE_DIR, '.dev-leads-key');
  try {
    const saved = fs.readFileSync(devKeyFile, 'utf8').trim();
    if (!/^[a-fA-F0-9]{64}$/.test(saved)) throw new Error('Chave local inválida: storage/.dev-leads-key.');
    return Buffer.from(saved, 'hex');
  }
  catch (error) {
    if (error.code !== 'ENOENT') throw error;
    const key = crypto.randomBytes(32);
    try { fs.writeFileSync(devKeyFile, key.toString('hex'), { mode: 0o600, flag: 'wx' }); }
    catch (writeError) { if (writeError.code !== 'EEXIST') throw writeError; return Buffer.from(fs.readFileSync(devKeyFile, 'utf8').trim(), 'hex'); }
    return key;
  }
}

function validateConfig() {
  if (!PRODUCTION) return;
  if (!SITE_URL || new URL(SITE_URL).protocol !== 'https:' || new URL(SITE_URL).pathname !== '/' || new URL(SITE_URL).search) {
    throw new Error('Produção bloqueada: configure SITE_URL=https://seudominio.com.br (sem caminho).');
  }
  if (!TURNSTILE_SITE_KEY || !TURNSTILE_SECRET_KEY || /^COLE_|^SUA_/i.test(TURNSTILE_SITE_KEY) || /^COLE_|^SUA_/i.test(TURNSTILE_SECRET_KEY)) {
    throw new Error('Produção bloqueada: configure TURNSTILE_SITE_KEY e TURNSTILE_SECRET_KEY válidas.');
  }
}

validateConfig();
const ENCRYPTION_KEY = setupKey();
const CSP = [
  "default-src 'none'",
  "base-uri 'none'",
  "object-src 'none'",
  "frame-ancestors 'none'",
  "form-action 'self'",
  "script-src 'self' https://challenges.cloudflare.com",
  "style-src 'self' https://fonts.googleapis.com",
  "img-src 'self' data: https://challenges.cloudflare.com",
  "font-src 'self' https://fonts.gstatic.com",
  "connect-src 'self' https://challenges.cloudflare.com",
  'frame-src https://challenges.cloudflare.com',
  ...(PRODUCTION ? ['upgrade-insecure-requests'] : [])
].join('; ');

function secureHeaders(res) {
  res.setHeader('Content-Security-Policy', CSP);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('X-XSS-Protection', '0');
  res.setHeader('X-DNS-Prefetch-Control', 'off');
  if (PRODUCTION) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
}

function sendJson(res, status, data, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(data));
}

// Controle adicional: útil por processo, não substitui rate limiting/WAF na borda.
const ipWindows = new Map();
const globalWindows = new Map();
function withinLimit(store, key, max, durationMs) {
  const now = Date.now();
  let count = store.get(key);
  if (!count || now >= count.reset) count = { hits: 0, reset: now + durationMs };
  count.hits++;
  store.set(key, count);
  if (store.size > 10000) for (const [k, entry] of store) if (entry.reset <= now) store.delete(k);
  return count.hits <= max;
}
const cleanup = setInterval(() => {
  const now = Date.now();
  for (const store of [ipWindows, globalWindows]) {
    for (const [key, v] of store) if (v.reset <= now) store.delete(key);
  }
}, 60_000);
cleanup.unref();

function requestIp(req) {
  // Não confiar em X-Forwarded-For ou CF-Connecting-IP sem validar o proxy.
  // Atrás de um proxy, todos os clientes podem compartilhar este limite.
  return req.socket.remoteAddress || 'unknown';
}

function encryptEntry(data) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', ENCRYPTION_KEY, iv);
  const ciphertext = Buffer.concat([cipher.update(JSON.stringify(data), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return JSON.stringify({ v: 1, iv: iv.toString('base64'), tag: tag.toString('base64'), data: ciphertext.toString('base64') }) + '\n';
}

function cleanText(value, max) {
  if (typeof value !== 'string') return null;
  const cleaned = value.trim().replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s{2,}/g, ' ');
  return cleaned.length <= max ? cleaned : null;
}
const SERVICES = new Set(['Diagnóstico completo', 'Tráfego pago', 'Social media', 'Automação', 'Campanhas de mensagens', 'CRM profissional']);

function validateLead(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return null;
  const name = cleanText(body.name, 90);
  const business = cleanText(body.business ?? '', 110);
  const phone = typeof body.phone === 'string' ? body.phone.trim() : '';
  const service = cleanText(body.service, 60);
  if (!name || name.length < 2 || !business && business !== '' ||
      !/^[+()\d\s-]{10,24}$/.test(phone) || !/^\+?\d{10,15}$/.test(phone.replace(/[()\s-]/g, '')) ||
      !service || !SERVICES.has(service) || body.consent !== true) return null;
  return { name, phone, business, service, consent: true, consentAt: new Date().toISOString(), purpose: 'retorno de contato comercial', source: 'matryx-landing-page' };
}

async function readJson(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) { const err = new Error('payload too large'); err.httpStatus = 413; throw err; }
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch (_) { const err = new Error('invalid JSON'); err.httpStatus = 400; throw err; }
}

async function validateTurnstile(token) {
  if (!TURNSTILE_SITE_KEY || !TURNSTILE_SECRET_KEY) return !PRODUCTION;
  if (typeof token !== 'string' || token.length < 10 || token.length > 2048) return false;
  const body = new URLSearchParams({ secret: TURNSTILE_SECRET_KEY, response: token });
  const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString(), signal: AbortSignal.timeout(6500)
  });
  if (!response.ok) throw new Error('Turnstile indisponível');
  const result = await response.json();
  return result.success === true && result.action === 'lead' && (!PRODUCTION || result.hostname === EXPECTED_HOSTNAME);
}

function acceptableOrigin(req) {
  const origin = req.headers.origin;
  if (typeof origin !== 'string') return false;
  try {
    const parsed = new URL(origin);
    const expected = SITE_URL ? new URL(SITE_URL).origin : `http://${req.headers.host}`;
    return parsed.origin === expected && req.headers['sec-fetch-site'] !== 'cross-site';
  } catch (_) { return false; }
}

async function handleLead(req, res) {
  const ip = requestIp(req);
  if (!withinLimit(globalWindows, 'leads-minute', 150, 60_000) ||
      !withinLimit(ipWindows, `leads-10min:${ip}`, 8, 600_000) ||
      !withinLimit(ipWindows, `leads-day:${ip}`, 40, 86_400_000)) {
    return sendJson(res, 429, { error: 'Muitas solicitações. Tente novamente mais tarde.' }, { 'Retry-After': '600' });
  }
  if (!acceptableOrigin(req)) return sendJson(res, 403, { error: 'Origem não autorizada.' });
  if (!/^application\/json(?:;\s*charset=utf-8)?$/i.test(req.headers['content-type'] || '')) {
    return sendJson(res, 415, { error: 'Envie os dados em JSON.' });
  }
  if (Number(req.headers['content-length'] || '0') > MAX_BODY_BYTES) {
    return sendJson(res, 413, { error: 'Solicitação excede o limite permitido.' });
  }
  let body;
  try { body = await readJson(req); }
  catch (error) { return sendJson(res, error.httpStatus || 400, { error: 'Não foi possível interpretar os dados.' }); }
  // Campo falso para desencorajar automações triviais sem armazenar dados.
  if (typeof body.website === 'string' && body.website.trim()) return sendJson(res, 201, { ok: true });
  const lead = validateLead(body);
  if (!lead) return sendJson(res, 400, { error: 'Revise nome, telefone, serviço e autorização de contato.' });
  try {
    const permitted = await validateTurnstile(body.turnstileToken);
    if (!permitted) return sendJson(res, 403, { error: 'Verificação de segurança inválida. Tente novamente.' });
  } catch (_) { return sendJson(res, 503, { error: 'Verificação de segurança indisponível. Tente novamente.' }); }
  try {
    await fsp.mkdir(STORAGE_DIR, { recursive: true, mode: 0o700 });
    await fsp.appendFile(LEADS_FILE, encryptEntry(lead), { encoding: 'utf8', mode: 0o600, flag: 'a' });
    return sendJson(res, 201, { ok: true });
  } catch (_) { return sendJson(res, 503, { error: 'Não foi possível concluir o envio. Tente novamente.' }); }
}

async function serveStatic(req, res, pathname) {
  const entry = files.get(pathname);
  if (!entry) return sendJson(res, 404, { error: 'Não encontrado.' });
  const [file, mime] = entry;
  const abs = path.join(PUBLIC_DIR, file);
  try {
    const stat = await fsp.stat(abs);
    const isHtml = mime.startsWith('text/html');
    const isConfig = pathname === '/config.js';
    const headers = {
      'Content-Type': mime,
      'Cache-Control': isHtml || isConfig ? 'no-store' : 'public, max-age=3600',
      'Content-Length': stat.size
    };
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    const stream = fs.createReadStream(abs);
    stream.on('error', () => res.destroy());
    stream.pipe(res);
  } catch (_) { return sendJson(res, 404, { error: 'Não encontrado.' }); }
}

function createServer() {
  const server = http.createServer(async (req, res) => {
    secureHeaders(res);
    try {
      if (PRODUCTION && req.headers.host !== new URL(SITE_URL).host) {
        return sendJson(res, 421, { error: 'Domínio não autorizado.' });
      }
      const pathname = new URL(req.url, 'http://localhost').pathname;
      if (req.method === 'GET' && pathname === '/api/public-config') {
        return sendJson(res, 200, { turnstileEnabled: Boolean(TURNSTILE_SITE_KEY && TURNSTILE_SECRET_KEY), siteKey: TURNSTILE_SITE_KEY });
      }
      if (req.method === 'POST' && pathname === '/api/leads') return await handleLead(req, res);
      if ((req.method === 'GET' || req.method === 'HEAD') && files.has(pathname)) return await serveStatic(req, res, pathname);
      if (files.has(pathname) || pathname === '/api/leads' || pathname === '/api/public-config') {
        return sendJson(res, 405, { error: 'Método não permitido.' }, { Allow: pathname === '/api/leads' ? 'POST' : 'GET, HEAD' });
      }
      return sendJson(res, 404, { error: 'Não encontrado.' });
    } catch (_) {
      if (!res.headersSent) return sendJson(res, 500, { error: 'Erro interno.' });
      res.destroy();
    }
  });
  server.requestTimeout = 15_000;
  server.headersTimeout = 10_000;
  server.keepAliveTimeout = 5_000;
  server.maxHeadersCount = 60;
  server.maxRequestsPerSocket = 100;
  return server;
}

if (require.main === module) {
  const server = createServer();
  const port = process.env.PORT === '0' ? 0 : Number(process.env.PORT) || 3000;
  server.listen(port, '0.0.0.0', () => console.info(`MATRYX ativa na porta ${server.address().port} (${PRODUCTION ? 'production' : 'development'})`));
}

module.exports = { createServer, encryptEntry, validateLead };
