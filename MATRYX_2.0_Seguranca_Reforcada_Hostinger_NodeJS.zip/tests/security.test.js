'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'matryx-security-'));
process.env.NODE_ENV = 'test';
process.env.STORAGE_DIR = temporary;
delete process.env.LEADS_ENCRYPTION_KEY;
delete process.env.TURNSTILE_SITE_KEY;
delete process.env.TURNSTILE_SECRET_KEY;
delete process.env.SITE_URL;
const { createServer } = require('../server');
const server = createServer();
let base;
const lead = { name:'Pessoa Teste', phone:'(94) 99999-9999', business:'Empresa Teste', service:'Tráfego pago', consent:true };

function post(body, headers={}) {
  return fetch(base + '/api/leads', {
    method:'POST',
    headers:{ 'Content-Type':'application/json', Origin:base, ...headers },
    body:typeof body==='string' ? body : JSON.stringify(body)
  });
}

test.before(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(async () => {
  await new Promise(resolve => server.close(resolve));
  fs.rmSync(temporary, { recursive:true, force:true });
});

test('site acessível, com CSP e cabeçalhos de segurança', async () => {
  const response=await fetch(base + '/');
  const html=await response.text();
  assert.equal(response.status, 200);
  assert.match(html, /MATRYX/);
  assert.match(html, /fundador\.webp/);
  assert.match(response.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  assert.match(response.headers.get('content-security-policy'), /script-src 'self'/);
  assert.equal(response.headers.get('x-frame-options'), 'DENY');
  assert.equal(response.headers.get('x-content-type-options'), 'nosniff');
  assert.doesNotMatch(html, /style="/);
});

test('arquivos e caminhos privados nunca são expostos', async () => {
  for (const route of ['/server.js','/.env','/storage/.dev-leads-key','/../../server.js','/%2e%2e%2fserver.js','/package.json','/api/admin']) {
    const response=await fetch(base+route);
    assert.equal(response.status, 404, `${route} deveria ser 404`);
    assert.doesNotMatch(await response.text(), /LEADS_ENCRYPTION_KEY|BEGIN PRIVATE KEY/);
  }
  const response=await fetch(base+'/api/leads');
  assert.equal(response.status,405);
});

test('rejeita requisições de origem externa, malformadas ou sem permissão', async () => {
  assert.equal((await post(lead, { Origin:'https://atacante.example' })).status, 403);
  assert.equal((await post('{', {})).status, 400);
  assert.equal((await post({ ...lead, consent:false })).status, 400);
  assert.equal((await post({ ...lead, service:'admin' })).status, 400);
  assert.equal((await post({ ...lead, name:'a'.repeat(200) })).status, 400);
});

test('apenas dados criptografados são gravados no servidor', async () => {
  const response=await post(lead);
  assert.equal(response.status, 201);
  assert.deepEqual(await response.json(), {ok:true});
  const file=fs.readFileSync(path.join(temporary, 'leads.enc.jsonl'), 'utf8');
  assert.doesNotMatch(file, /Pessoa Teste|99999|Empresa Teste/);
  const record=JSON.parse(file.trim().split('\n')[0]);
  const key=Buffer.from(fs.readFileSync(path.join(temporary, '.dev-leads-key'),'utf8'), 'hex');
  const decipher=crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(record.iv,'base64'));
  decipher.setAuthTag(Buffer.from(record.tag,'base64'));
  const payload=JSON.parse(Buffer.concat([decipher.update(Buffer.from(record.data,'base64')),decipher.final()]).toString('utf8'));
  assert.equal(payload.name, 'Pessoa Teste');
  assert.equal(payload.service, 'Tráfego pago');
  assert.equal(payload.consent, true);
});

test('rejeita payload grande antes da escrita', async () => {
  const response=await post({ ...lead, business:'x'.repeat(9000) });
  assert.equal(response.status, 413);
});

test('limita solicitações abusivas por IP', async () => {
  const results=[];
  for (let i=0;i<4;i++) results.push((await post(lead)).status);
  assert.ok(results.includes(429), 'espera-se ao menos um bloqueio 429 por taxa');
});
