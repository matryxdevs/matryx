(() => {
  const cfg = window.MATRYX_CONFIG || {};
  const $ = (selector) => document.querySelector(selector);
  const navToggle = $('.menu-toggle');
  const nav = $('.nav-links');
  navToggle?.addEventListener('click', () => {
    const opened = nav.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(opened));
  });
  nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('is-open');
    navToggle?.setAttribute('aria-expanded', 'false');
  }));
  $('#year').textContent = new Date().getFullYear();
  const insta = $('#instagram-link');
  if (cfg.instagram && /^https:\/\//.test(cfg.instagram)) { insta.href = cfg.instagram; insta.hidden = false; }
  document.querySelectorAll('[data-service]').forEach(button => button.addEventListener('click', () => {
    $('#lead-service').value = button.dataset.service;
    $('#diagnostico').scrollIntoView({ behavior: 'smooth' });
    setTimeout(() => $('#lead-name').focus({ preventScroll: true }), 650);
  }));
  const form = $('#lead-form');
  const submitButton = form.querySelector('[type=submit]');
  const feedback = $('#form-feedback');
  let captchaToken = '';
  let captchaId = null;
  let captchaRequired = false;
  let captchaReady = false;

  function setFormStatus(message, disabled) {
    feedback.textContent = message;
    submitButton.disabled = disabled;
  }
  // O identificador público é obtido do servidor; a chave secreta NUNCA vai ao navegador.
  async function initializeSecurity() {
    submitButton.disabled = true;
    try {
      const response = await fetch('/api/public-config', { cache: 'no-store' });
      if (!response.ok) throw new Error('Configuração de segurança indisponível.');
      const config = await response.json();
      captchaRequired = config.turnstileEnabled === true;
      if (!captchaRequired) { captchaReady = true; submitButton.disabled = false; return; }
      if (!config.siteKey) throw new Error('Verificação não configurada.');
      $('#turnstile-box').hidden = false;
      const script = document.createElement('script');
      script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      script.async = true;
      script.addEventListener('load', () => {
        try {
          captchaId = window.turnstile.render('#turnstile-widget', {
            sitekey: config.siteKey,
            action: 'lead',
            theme: 'dark',
            callback: token => { captchaToken = token; submitButton.disabled = false; feedback.textContent = ''; },
            'expired-callback': () => { captchaToken = ''; submitButton.disabled = true; },
            'error-callback': () => { captchaToken = ''; setFormStatus('Verificação indisponível. Atualize a página para tentar novamente.', true); }
          });
          captchaReady = true;
        } catch (_) { setFormStatus('Não foi possível carregar a verificação de segurança.', true); }
      });
      script.addEventListener('error', () => setFormStatus('Verificação bloqueada pela rede ou navegador.', true));
      document.head.appendChild(script);
    } catch (_) { setFormStatus('Não foi possível iniciar a proteção do formulário. Atualize a página.', true); }
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!form.reportValidity() || !captchaReady || (captchaRequired && !captchaToken)) return;
    const data = Object.fromEntries(new FormData(form));
    data.consent = Boolean(data.consent);
    data.turnstileToken = captchaRequired ? captchaToken : '';
    submitButton.disabled = true;
    submitButton.textContent = 'ENVIANDO SOLICITAÇÃO...';
    feedback.textContent = '';
    try {
      const response = await fetch('/api/leads', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data), cache: 'no-store'
      });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.error || 'Não foi possível enviar.');
      feedback.textContent = 'Solicitação registrada!';
      const phone = String(cfg.whatsapp || '').replace(/\D/g, '');
      if (phone.length >= 12 && phone.length <= 15) {
        const message = `Olá, Matryx! Quero um diagnóstico.\nNome: ${data.name}\nWhatsApp: ${data.phone}\nEmpresa: ${data.business || 'Não informada'}\nInteresse: ${data.service}`;
        feedback.textContent = 'Solicitação registrada! Clique para continuar no WhatsApp.';
        const wa = document.createElement('a');
        wa.href = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
        wa.target = '_blank'; wa.rel = 'noopener noreferrer';
        wa.textContent = 'ABRIR CONVERSA NO WHATSAPP ↗';
        wa.className = 'btn btn-primary whatsapp-button';
        feedback.append(document.createElement('br'), wa);
        window.open(wa.href, '_blank', 'noopener,noreferrer');
      } else {
        feedback.textContent = 'Solicitação registrada! Entraremos em contato pelo número informado.';
      }
      form.reset();
    } catch (error) { feedback.textContent = error.message || 'Falha no envio. Tente novamente.'; }
    finally {
      if (captchaRequired && captchaId !== null && window.turnstile) {
        captchaToken = '';
        window.turnstile.reset(captchaId);
      }
      submitButton.disabled = captchaRequired;
      submitButton.textContent = 'SOLICITAR DIAGNÓSTICO ↗';
    }
  });
  initializeSecurity();
})();
