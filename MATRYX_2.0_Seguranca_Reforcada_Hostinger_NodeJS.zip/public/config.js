// EDITE AQUI: adicione seus contatos reais antes de publicar.
window.MATRYX_CONFIG = {
  whatsapp: '', // Exemplo: '5594999999999' (somente números, DDI + DDD)
  instagram: '', // Exemplo: 'https://instagram.com/suaagencia'
  email: '', // Exemplo: 'contato@matryx.com.br'
  calendly: '', // Opcional: link de agendamento
  metaPixelId: '', // Opcional. Só ativar após configurar consentimento de cookies.
};
