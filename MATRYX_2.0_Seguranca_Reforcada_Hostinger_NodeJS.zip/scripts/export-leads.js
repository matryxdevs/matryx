'use strict';
// Uso local: LEADS_ENCRYPTION_KEY=... node scripts/export-leads.js > exportacao.csv
// Nunca rode como endpoint público nem grave CSV na pasta public/.
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const keyHex = process.env.LEADS_ENCRYPTION_KEY || '';
if (!/^[a-fA-F\d]{64}$/.test(keyHex)) {
  console.error('Defina LEADS_ENCRYPTION_KEY como a chave de 64 caracteres hexadecimais da produção.');
  process.exit(1);
}
const key = Buffer.from(keyHex, 'hex');
const root = process.env.STORAGE_DIR ? path.resolve(process.env.STORAGE_DIR) : path.join(__dirname, '..', 'storage');
const file = path.join(root, 'leads.enc.jsonl');
const escapeCsv = v => {
  const input = String(v ?? '');
  // Evita execução de fórmulas ao abrir o CSV em uma planilha.
  const guarded = /^[\s\t]*[=+@\-]/.test(input) ? "'" + input : input;
  return '"' + guarded.replace(/"/g, '""') + '"';
};
console.log(['Data de consentimento','Nome','WhatsApp','Empresa','Serviço','Finalidade'].map(escapeCsv).join(','));
const lines = fs.readFileSync(file,'utf8').split('\n').filter(Boolean);
for (const line of lines) {
  const entry = JSON.parse(line);
  if (entry.v !== 1) throw new Error('Formato criptográfico desconhecido');
  const decipher = crypto.createDecipheriv('aes-256-gcm',key,Buffer.from(entry.iv,'base64'));
  decipher.setAuthTag(Buffer.from(entry.tag,'base64'));
  const lead = JSON.parse(Buffer.concat([decipher.update(Buffer.from(entry.data,'base64')),decipher.final()]).toString('utf8'));
  console.log([lead.consentAt, lead.name, lead.phone, lead.business, lead.service, lead.purpose].map(escapeCsv).join(','));
}
