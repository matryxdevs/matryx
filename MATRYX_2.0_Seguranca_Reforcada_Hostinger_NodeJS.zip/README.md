# MATRYX 2.0 — Site Node.js com segurança reforçada

Landing page de alta conversão com estética hacker e foto do fundador, pronta para editar no VS Code e implantar em hospedagem Hostinger **com suporte a aplicativos Node.js**.

> **Segurança realista:** nenhum site é 100% inviolável. As proteções deste projeto reduzem riscos comuns, mas dependem de HTTPS, WAF, atualização de software, políticas de acesso, backups, configuração correta da infraestrutura e monitoramento. Não substitui teste de invasão autorizado/auditoria antes de um lançamento crítico.

## 1. Abrir e testar no VS Code

Requer Node.js **22 ou superior**, por usar funções criptográficas e APIs nativas. Não há bibliotecas externas a instalar.

```bash
npm run dev
```

Acesse **http://localhost:3000**. A página abre com sua foto em `public/assets/fundador.webp` e o formulário funciona localmente, sem captcha. Para desenvolvimento, o projeto cria um arquivo `storage/.dev-leads-key` (chave local) e armazena os leads criptografados em `storage/leads.enc.jsonl`. **Não publique nem compartilhe essa pasta.**

Edite:

- `public/config.js`: WhatsApp comercial (DDI+DDD, somente números) e Instagram.
- `public/index.html`: textos comerciais e informações institucionais.
- `public/style.css`: cores e layout.

## 2. Publicar na Hostinger (obrigatório configurar antes)

Confirme que seu plano e painel Hostinger suportam **Node.js 22+** e permitem definir variáveis de ambiente e um diretório de armazenamento **persistente e privado**.

1. Extraia o ZIP, entre na pasta `matryx-agencia-segura` e configure `public/config.js`.
2. Em seu domínio, ative HTTPS/SSL; configure redirecionamento **HTTP → HTTPS** no painel/proxy.
3. Acesse https://dash.cloudflare.com/ e crie um widget **Turnstile** para o domínio final; obtenha a **site key pública** e a **secret key privada**. Ative proteção WAF/bot e restrições no domínio/proxy, conforme disponíveis.
4. Gere uma chave de criptografia executando `npm run keygen`. Guarde a chave num cofre de senhas; **não envie essa chave por WhatsApp, e-mail, Git ou para a pasta public**.
5. Na Hostinger, configure estas variáveis de ambiente (copie a estrutura do `.env.example` e substitua os valores):

```text
NODE_ENV=production
SITE_URL=https://seudominio.com.br
LEADS_ENCRYPTION_KEY=64_CARACTERES_HEXADECIMAIS_GERADOS_PELO_KEYGEN
TURNSTILE_SITE_KEY=SUA_SITE_KEY_PUBLICA
TURNSTILE_SECRET_KEY=SUA_SECRET_KEY_PRIVADA
```

> **Não** deixe placeholders como `COLE_AQUI...`: a aplicação pode iniciar, mas falhar na validação. Teste a gravação de um contato real após a implantação. Não coloque segredos em `public/config.js`.

6. Implante o conteúdo da pasta raiz no app Node.js da Hostinger, mantendo `server.js` e `package.json` na raiz. Defina **comando de inicialização `npm start`** e versão Node.js **22+**. A variável `PORT`, quando fornecida pela hospedagem, é usada automaticamente. A aplicação não necessita de `npm install` para dependências externas.
7. Configure, se necessário, `STORAGE_DIR` para uma pasta persistente **fora de public/**; não use sistema de arquivos efêmero. Garanta acesso somente ao processo da aplicação.
8. Teste a página, a verificação Turnstile e o envio do formulário no domínio **HTTPS**. Revise os relatórios do firewall e as permissões da pasta de dados.

### Comportamento de segurança em produção

A aplicação **não inicia** com `NODE_ENV=production` sem `SITE_URL` HTTPS, `LEADS_ENCRYPTION_KEY` de 256 bits (64 hex) e ambas as chaves Turnstile. O backend verifica todos os tokens recebidos usando a API Siteverify do Cloudflare e checa o domínio e a ação `lead`. Caso o serviço de validação falhe, o envio é recusado. Nenhuma chave secreta é enviada ao navegador.

## 3. Proteções implementadas

- Servidor HTTP do Node.js sem dependências NPM de terceiros: superfície de ataque reduzida.
- Lista fechada de arquivos públicos. Bloqueio de `/.env`, `server.js`, `storage`, `package.json` e outras rotas não autorizadas (404).
- CSP (Content Security Policy) para scripts, estilos e recursos permitidos; sem JavaScript inline; `frame-ancestors 'none'` e `X-Frame-Options: DENY` contra clickjacking.
- `X-Content-Type-Options: nosniff`, Referrer Policy, permissões restritivas e HSTS em produção.
- Verificação de origem do navegador, `Sec-Fetch-Site`, `Content-Type`, tamanho máximo do JSON e parâmetros com listas válidas.
- Rate limiting em memória para envios por conexão de rede/IP e limite global para ajudar a conter tentativas automatizadas. **Atrás de proxy, o IP pode ser o do proxy, e o limite não é distribuído entre instâncias: mantenha WAF e limites na borda.**
- Honeypot básico anti-spam e Cloudflare Turnstile validado no **servidor** (exigido em produção).
- Leads gravados fora da área pública com criptografia autenticada **AES-256-GCM**, IV aleatório por registro. Não há endpoint público de consulta ou administração.
- Timeouts para conexões, corpo de requisição limitado a 8 KiB e respostas de erro sem dados internos.

## 4. Recuperar leads

O arquivo `storage/leads.enc.jsonl` está **criptografado**. Não adianta abrir o arquivo com o editor para ler nomes e números.

Para exportar com segurança no terminal autorizado do servidor (ou após copiar arquivo e chave para uma máquina confiável):

```bash
LEADS_ENCRYPTION_KEY=COLE_SUA_CHAVE npm run export:leads > contatos-matryx.csv
```

Windows PowerShell:

```powershell
$env:LEADS_ENCRYPTION_KEY="SUA_CHAVE"; npm run export:leads > contatos-matryx.csv
```

**Proteja e apague os CSVs exportados** quando não forem necessários. Não disponibilize o arquivo em pastas públicas. Faça backup seguro da chave e dos dados juntos, mas em locais/controles de acesso separados. Perdendo a chave, perde-se o acesso aos leads criptografados.

Este armazenamento em arquivo é apropriado para **uma instância com disco persistente**. Para escala, múltiplas instâncias ou integração ao CRM, migre para banco de dados seguro ou serviço apropriado, com controles de acesso e gestão de chaves.

## 5. Testes incluídos

```bash
npm test
```

Inclui testes de cabeçalhos de segurança, exposição de arquivos privados, validação de requisições, limitação de abuso, fluxo do formulário e criptografia. Esses testes **não** substituem uma auditoria de infraestrutura, teste de penetração ou validação em ambiente de produção.

## 6. Segurança operacional, privacidade e LGPD

- Ative MFA na Hostinger, Cloudflare e demais serviços, use contas distintas e senhas únicas.
- Aplique atualizações de Node.js, servidor, DNS e painel; remova acessos de terceiros que não precisam mais deles.
- Use SSL/TLS válido e bloqueie o acesso direto à origem se colocar o domínio atrás do Cloudflare, quando a hospedagem permitir.
- Configure WAF, regras de rate limiting/bot, backups criptografados e alarmes de indisponibilidade/erro.
- Os dados de contato são pessoais. Personalize e publique uma **política de privacidade** verdadeira com identidade do controlador, finalidades, bases legais, retenção, canal de direitos e segurança. O texto atual é apenas informativo e exige revisão antes do lançamento.
- Faça envios em escala somente para destinatários com base legal adequada, respeitando LGPD, regras das plataformas e o descadastramento.
- Não ligue pixel de rastreamento ou cookies não necessários antes de implementar o consentimento apropriado.

## Estrutura

```text
matryx-agencia-segura/
├── server.js                  # API segura e servidor estático
├── package.json               # Scripts Node.js
├── .env.example               # Modelo de variáveis (não contém segredos)
├── .gitignore                 # Protege chaves, armazenamento e exportações
├── README.md
├── scripts/export-leads.js    # Exportação LOCAL de dados criptografados
├── tests/security.test.js     # Testes automatizados
└── public/
    ├── index.html
    ├── style.css
    ├── script.js
    ├── config.js              # Somente dados PÚBLICOS
    └── assets/
        ├── founder...         # Sua foto (fundador.webp/fundador.jpg)
        └── favicon.svg
```
