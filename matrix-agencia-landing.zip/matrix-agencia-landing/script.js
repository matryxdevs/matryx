'use strict';

/* O site é 100% estático. Não possui backend, APIs, armazenamento de leads
 * nem dependências externas. Os dados são compartilhados somente quando
 * o visitante decide enviar a mensagem no próprio WhatsApp. */

const MATRIX_WHATSAPP = '5594984056659';

const form = document.getElementById('lead-form');
const nameInput = document.getElementById('lead-name');
const phoneInput = document.getElementById('lead-phone');
const interestInput = document.getElementById('lead-interest');
const consentInput = document.getElementById('lead-consent');
const errorNode = document.getElementById('form-error');
const yearNode = document.getElementById('current-year');

if (yearNode) yearNode.textContent = String(new Date().getFullYear());

function normalizeBrazilianPhone(input) {
  let digits = input.replace(/\D/g, '');
  if ((digits.length === 12 || digits.length === 13) && digits.startsWith('55')) {
    digits = digits.slice(2);
  }
  if (!/^\d{10,11}$/.test(digits)) return null;
  const ddd = Number(digits.slice(0, 2));
  if (ddd < 11 || ddd > 99) return null;
  return digits;
}

function presentPhone(input) {
  const value = input.replace(/\D/g, '').slice(0, 11);
  if (value.length <= 2) return value;
  if (value.length <= 6) return `(${value.slice(0, 2)}) ${value.slice(2)}`;
  if (value.length <= 10) return `(${value.slice(0, 2)}) ${value.slice(2, 6)}-${value.slice(6)}`;
  return `(${value.slice(0, 2)}) ${value.slice(2, 7)}-${value.slice(7)}`;
}

if (phoneInput) {
  phoneInput.addEventListener('input', () => {
    // Não converte telefones digitados com +55; apenas formata números locais.
    const onlyDigits = phoneInput.value.replace(/\D/g, '');
    if (onlyDigits.length <= 11) phoneInput.value = presentPhone(phoneInput.value);
    if (errorNode) errorNode.textContent = '';
  });
}

if (form && nameInput && phoneInput && interestInput && consentInput && errorNode) {
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    errorNode.textContent = '';

    const name = nameInput.value.trim().replace(/\s+/g, ' ');
    const phone = normalizeBrazilianPhone(phoneInput.value);
    const interest = interestInput.value;
    const validInterests = new Set([
      'Tráfego pago', 'Social media', 'Automação de processos',
      'Mensagens em escala com consentimento', 'CRM profissional',
      'Solução completa de marketing e vendas'
    ]);

    if (name.length < 2 || name.length > 70) {
      errorNode.textContent = 'Informe seu nome (de 2 a 70 caracteres).';
      nameInput.focus();
      return;
    }
    if (!phone) {
      errorNode.textContent = 'Informe um WhatsApp brasileiro válido, com DDD.';
      phoneInput.focus();
      return;
    }
    if (!validInterests.has(interest)) {
      errorNode.textContent = 'Selecione o serviço que você deseja conhecer.';
      interestInput.focus();
      return;
    }
    if (!consentInput.checked) {
      errorNode.textContent = 'Confirme que deseja compartilhar os dados pelo WhatsApp.';
      consentInput.focus();
      return;
    }

    const message = [
      'Olá, equipe MATRIX! Gostaria de solicitar um atendimento.',
      '',
      `*Nome:* ${name}`,
      `*WhatsApp:* +55 ${phone}`,
      `*Serviço de interesse:* ${interest}`,
      '',
      'Quero saber como a MATRIX pode ajudar minha empresa.'
    ].join('\n');

    // Destino fixo, sem redirecionamentos controlados por dados do visitante.
    const destination = `https://wa.me/${MATRIX_WHATSAPP}?text=${encodeURIComponent(message)}`;
    window.location.assign(destination);
  });
}

/* Efeito visual de caracteres Matrix: leve, sem bibliotecas e respeitando a
 * preferência de movimento reduzido. O canvas não captura dados de usuários. */
(function initMatrixRain() {
  const canvas = document.getElementById('matrix-rain');
  if (!canvas || !canvas.getContext || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const ctx = canvas.getContext('2d', { alpha: true });
  if (!ctx) return;

  const chars = '01アイウエオ<>/{}[]+=-';
  const fontSize = 15;
  let columns = [];
  let cssWidth = 0;
  let cssHeight = 0;
  let frameId = null;
  let lastTick = 0;

  function resize() {
    cssWidth = Math.max(320, document.documentElement.clientWidth);
    cssHeight = Math.min(930, Math.max(610, window.innerHeight + 160));
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    canvas.style.height = `${cssHeight}px`;
    canvas.width = Math.round(cssWidth * ratio);
    canvas.height = Math.round(cssHeight * ratio);
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    columns = Array.from({ length: Math.ceil(cssWidth / fontSize) }, () =>
      Math.random() * (cssHeight / fontSize) * -1
    );
  }

  function draw(now) {
    frameId = window.requestAnimationFrame(draw);
    if (now - lastTick < 70) return; // ~14 fps, menor uso de CPU
    lastTick = now;
    ctx.fillStyle = 'rgba(8, 12, 12, .13)';
    ctx.fillRect(0, 0, cssWidth, cssHeight);
    ctx.font = `12px ui-monospace, monospace`;
    ctx.fillStyle = '#74dd84';
    for (let i = 0; i < columns.length; i++) {
      const character = chars[Math.floor(Math.random() * chars.length)];
      const x = i * fontSize;
      const y = columns[i] * fontSize;
      ctx.fillText(character, x, y);
      if (y > cssHeight && Math.random() > 0.973) columns[i] = 0;
      else columns[i] += 0.43;
    }
  }

  function setAnimationState() {
    if (document.hidden) {
      if (frameId !== null) window.cancelAnimationFrame(frameId);
      frameId = null;
    } else if (frameId === null) {
      frameId = window.requestAnimationFrame(draw);
    }
  }

  resize();
  window.addEventListener('resize', resize, { passive: true });
  document.addEventListener('visibilitychange', setAnimationState);
  setAnimationState();
})();
